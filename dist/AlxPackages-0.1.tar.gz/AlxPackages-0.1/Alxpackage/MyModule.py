def add(a ,b):
    """
    Simple text for DocString
    
    
    """
    return a+b
