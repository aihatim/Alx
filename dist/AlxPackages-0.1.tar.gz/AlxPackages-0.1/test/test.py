from Alxpackage import MyModule
def test_add():
    """
    Simple Test Function
    """
    assert MyModule.add(5,2)==7